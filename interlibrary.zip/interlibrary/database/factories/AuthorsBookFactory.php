<?php

namespace Database\Factories;

use App\Models\Book;
use App\Models\Author;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
// class AuthorsBookFactory extends Factory
// {
//     /**
//      * Define the model's default state.
//      *
//      * @return array<string, mixed>
//      */
//     public function definition(): array
//     {
//         $authorId = Author::inRandomOrder()->first()->id;
//         $bookId = Book::inRandomOrder()->first()->id;
//         return [
//             'author_id' => $authorId,
//             'book_id' => $bookId
//         ];
//     }
// }
